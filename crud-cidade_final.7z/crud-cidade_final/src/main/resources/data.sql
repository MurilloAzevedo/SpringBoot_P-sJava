
INSERT INTO `usuario` VALUES (1,'john','$2a$10$/.KKJU.G71/Fl.4wKo.lJOfDhxhHPo0o.DPxIy98IuKSaK74WXUy2');
INSERT INTO `usuario` VALUES (2,'anna','$2a$10$/.KKJU.G71/Fl.4wKo.lJOfDhxhHPo0o.DPxIy98IuKSaK74WXUy2');

INSERT INTO `usuario_papeis` VALUES (1, 'listar');
INSERT INTO `usuario_papeis` VALUES (2, 'listar');
INSERT INTO `usuario_papeis` VALUES (2, 'admin');